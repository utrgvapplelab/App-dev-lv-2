
// iOS Framework
import UIKit


// The Main View
class ViewController: UIViewController {

   // Elements on the view
    @IBOutlet weak var mainLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var rockButton: UIButton!
    @IBOutlet weak var paperButton: UIButton!
    @IBOutlet weak var scissorButton: UIButton!
    @IBOutlet weak var playAgain: UIButton!
    
    
    // Actions to be done after loading
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        resetBoard()
    }
    
    // Function to reset the screen
    func resetBoard() {
        mainLabel.text = "🤖"
        titleLabel.text = "Rock, Paper, Sicssors?"
        rockButton.isHidden = false
        paperButton.isHidden = false
        scissorButton.isHidden = false
        rockButton.isEnabled = true
        paperButton.isEnabled = true
        scissorButton.isEnabled = true
    }
    
    // Function to Play RPS
    func play(_ playerTurn: Sign) {
        rockButton.isEnabled = false
        paperButton.isEnabled = false
        scissorButton.isEnabled = false
    
    
    let opponent = randomSign()
    mainLabel.text = opponent.emoji
    
        let gameResult = playerTurn.takeTurn(opponent)
        
        switch gameResult {
        case .draw:
            titleLabel.text = "It's a Draw"
        case .lose:
            titleLabel.text = "Sorry, you lose"
        case .win:
            titleLabel.text = "Yes!, You Win"
        case .start:
            titleLabel.text = "Rock, Paper, Scissors?"
        }
        
        switch playerTurn {
        case .rock:
            rockButton.isHidden = false
            paperButton.isHidden = true
            scissorButton.isHidden = true
        case .paper:
            rockButton.isHidden = true
            paperButton.isHidden = false
            scissorButton.isHidden = true
        case .scissors:
            rockButton.isHidden = true
            paperButton.isHidden = true
            scissorButton.isHidden = false
        }
        
        playAgain.isHidden = false
    }
    
    // Function to Play Again RPS
    @IBAction func playAgain(_ sender: Any) {
        resetBoard()
    }
    
    // Function to Press Rock
    @IBAction func rockTab(_ sender: UIButton) {
        play(Sign.rock)
    }
    
    //Function to Press Paper
    @IBAction func paperTab(_ sender: UIButton) {
        play(Sign.paper)
    }
    
    // Function to Press Scissors
    @IBAction func scissorsTab(_ sender: UIButton) {
        play(Sign.scissors)
    }
}

