
// iOS Framework
import Foundation


// Game rules enum 
enum GameState {
    case start, win, lose, draw
}
