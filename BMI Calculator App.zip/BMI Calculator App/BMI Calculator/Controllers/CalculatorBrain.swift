import UIKit

struct CalculatorBrain {
 
    var bmi: BMI?
    
    mutating func calculateBMI(height: Float, weight: Float) {
        let bmiValue = weight / pow(height, 2)
        
        if bmiValue < 18.5 {
            bmi = BMI(value: bmiValue, advice: "Please Eat More, Thanks", color: .cyan)
           } else if bmiValue < 24.9 {
           bmi = BMI(value: bmiValue, advice: "Great Weight and Shape!", color: .green)
           } else {
           bmi = BMI(value: bmiValue, advice: "Please Eat Less :)", color: .red)
           }
    }
   
    func getAdvice() -> String {
        return bmi?.advice ?? "No advice"
    }
    
    func getColor() -> UIColor {
        return bmi?.color ?? UIColor.white
    }
    
     func getBMIValue() -> String {
        let bmiTo1Decimal = String(format:"%.1f",bmi?.value ?? 0.0)
            return bmiTo1Decimal
    }
}
